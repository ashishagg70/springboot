package com.infosys.irs.exception;

@SuppressWarnings("serial")
public class SourceNotFoundException extends Exception {
	public SourceNotFoundException(String message) {
		super(message);
	}

}
