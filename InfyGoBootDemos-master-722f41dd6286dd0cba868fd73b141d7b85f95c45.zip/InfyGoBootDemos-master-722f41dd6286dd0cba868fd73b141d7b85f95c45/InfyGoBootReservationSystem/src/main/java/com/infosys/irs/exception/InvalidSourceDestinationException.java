package com.infosys.irs.exception;
@SuppressWarnings("serial")
public class InvalidSourceDestinationException extends Exception{
	public InvalidSourceDestinationException(String message){
		super(message);
	}

}
