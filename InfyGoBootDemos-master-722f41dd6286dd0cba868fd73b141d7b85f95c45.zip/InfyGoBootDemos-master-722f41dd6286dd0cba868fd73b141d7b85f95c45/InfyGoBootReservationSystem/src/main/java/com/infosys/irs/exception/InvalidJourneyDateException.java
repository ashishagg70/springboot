package com.infosys.irs.exception;
@SuppressWarnings("serial")
public class InvalidJourneyDateException  extends Exception{

	public InvalidJourneyDateException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
