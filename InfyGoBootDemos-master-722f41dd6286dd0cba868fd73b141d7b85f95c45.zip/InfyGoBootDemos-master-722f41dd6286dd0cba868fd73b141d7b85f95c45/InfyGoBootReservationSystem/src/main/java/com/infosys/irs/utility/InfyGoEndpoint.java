package com.infosys.irs.utility;

import org.springframework.boot.actuate.endpoint.Endpoint;
import org.springframework.stereotype.Component;

@Component
public class InfyGoEndpoint implements Endpoint<String>{

	@Override
	public String getId() {
		return "infygoendpoint";
	}

	@Override
	public String invoke() {
		// Custom logic to build the output

		return "This is InfyGo custom endpoint message";
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean isSensitive() {
		return false;
	}

}
