package com.infosys.irs.exception;
@SuppressWarnings("serial")
public class PassengerDetailNotFoundException  extends Exception{
	public PassengerDetailNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
